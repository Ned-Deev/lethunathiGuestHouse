<?php
// Exception class stub
?>