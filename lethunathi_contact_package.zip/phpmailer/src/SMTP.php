<?php
// SMTP class stub
?>